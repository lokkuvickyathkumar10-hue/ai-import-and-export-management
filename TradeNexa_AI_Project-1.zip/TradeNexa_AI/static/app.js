document.addEventListener("DOMContentLoaded",()=>{
 const el=document.getElementById("tradeChart");
 if(el && window.Chart){
   new Chart(el,{type:"bar",data:{labels:["Imports","Exports"],datasets:[{label:"Recorded value",data:[Number(el.dataset.imports),Number(el.dataset.exports)],backgroundColor:["#1769aa","#58c5e8"],borderRadius:8}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
 }
});
